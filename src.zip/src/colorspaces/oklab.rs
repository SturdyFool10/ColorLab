/// Oklab color space and conversion to/from linear RGB (Color).
use crate::colorspaces::color::Color;
use crate::colorspaces::colorspace::ColorSpace;

/// Oklab color space (perceptual, 0.0-1.0 for L, usually -0.5..0.5 for a/b, 0.0-1.0 for alpha)
#[derive(Debug, Clone, Copy, PartialEq, Default)]
pub struct Oklab {
    pub l: f32,
    pub a: f32,
    pub b: f32,
    pub alpha: f32,
}

impl ColorSpace for Oklab {
    fn to_color(&self) -> Color {
        // Oklab to linear RGB
        let l = self.l;
        let a = self.a;
        let b = self.b;

        // 1. Oklab to LMS
        let l_ = l + 0.3963377774 * a + 0.2158037573 * b;
        let m_ = l - 0.1055613458 * a - 0.0638541728 * b;
        let s_ = l - 0.0894841775 * a - 1.2914855480 * b;

        // 2. LMS to nonlinear
        let l_cubed = l_ * l_ * l_;
        let m_cubed = m_ * m_ * m_;
        let s_cubed = s_ * s_ * s_;

        // 3. LMS to linear RGB
        let r = 4.0767416621 * l_cubed - 3.3077115913 * m_cubed + 0.2309699292 * s_cubed;
        let g = -1.2684380046 * l_cubed + 2.6097574011 * m_cubed - 0.3413193965 * s_cubed;
        let b = 0.0041960863 * l_cubed - 0.7034186147 * m_cubed + 1.7076147010 * s_cubed;

        Color {
            r,
            g,
            b,
            a: self.alpha,
        }
    }

    fn from_color(color: &Color) -> Self {
        // Linear RGB to Oklab
        let r = color.r;
        let g = color.g;
        let b = color.b;

        // 1. Linear RGB to LMS
        let l = 0.4122214708 * r + 0.5363325363 * g + 0.0514459929 * b;
        let m = 0.2119034982 * r + 0.6806995451 * g + 0.1073969566 * b;
        let s = 0.0883024619 * r + 0.2817188376 * g + 0.6299787005 * b;

        // 2. Cube root

        let l_ = l.cbrt();
        let m_ = m.cbrt();
        let s_ = s.cbrt();

        // 3. LMS to Oklab
        let l_lab = 0.2104542553 * l_ + 0.7936177850 * m_ - 0.0040720468 * s_;
        let a = 1.9779984951 * l_ - 2.4285922050 * m_ + 0.4505937099 * s_;
        let b = 0.0259040371 * l_ + 0.7827717662 * m_ - 0.8086757660 * s_;

        Oklab {
            l: l_lab,
            a,
            b,
            alpha: color.a,
        }
    }
}
